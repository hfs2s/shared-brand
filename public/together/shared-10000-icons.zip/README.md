# Shared icon library

The library includes 200 base symbols and 9,800 object–action icons. The original Inbox emoji are first. The full set is unframed. An action icon combines a clear object symbol with a separately drawn operation, such as **Download · File** or **Mute · Microphone**.

- **flat/** contains all 10,000 standalone SVGs.
- **paper-sprite.svg** contains equivalent paper versions, each clipped to its visible paths. One shared paper scan is embedded.
- **catalog.csv** maps every name to its SVG. A row without an action refers to a 16 × 16 base symbol. Action icons use a 32 × 24 grid.
- The studio icon library downloads any paper version as a self-contained SVG.

Use the flat base glyph for a compact labelled control. Use an action glyph where both parts fit and the label identifies the task.
