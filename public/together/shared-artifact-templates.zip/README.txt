Open Studio artifact starters

The example project, parties and figures are fictional. Edit the HTML files, keeping the CSS and media folder beside them. Replace all sample copy with the final information.
For print, use Print to PDF with background graphics enabled and browser headers and footers disabled. Use email.txt alongside the HTML email and replace the example details link with the event URL.
The slides PDF is an export from the hfs2s live-call deck store. To build a variation there, use open-studio-deck.json with hfs2s-deck new and attach media/artifact-workshop.jpg to slide 3.
