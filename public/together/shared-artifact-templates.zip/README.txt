Open Studio artifact starters

The example project, parties and figures are fictional. Edit the HTML files, keeping the CSS and media folder beside them. Replace all sample copy with the final information.
For print, use Print to PDF with background graphics enabled and browser headers and footers disabled. Use email.txt alongside the HTML email and replace the example details link with the event URL.
The slide PDF carries the Shared wordmark on the cover. Use open-studio-deck.json for the slide text and layouts. The workshop photograph for slide 3 is in media/artifact-workshop.jpg.
