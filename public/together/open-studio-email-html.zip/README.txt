Use email.html with images hosted at HTTPS URLs or embedded as CID attachments. Update the event URL and sender details. Use email.txt as the plain-text alternative.
